/**
 * MovieMatch - Frontend Application Logic
 * ---------------------------------------
 * Handles HTTP AJAX communications with the Flask backend API (/api/chat),
 * manages dynamic DOM manipulation for message rendering, formats markdown
 * responses, and processes UI events (Send button, Enter key, quick chips).
 * 
 * Academic Design:
 * Clean asynchronous JavaScript (ES6+ async/await) adhering to separation of
 * concerns between DOM state management and network communication.
 */

document.addEventListener("DOMContentLoaded", () => {
    // DOM Element References
    const chatMessages = document.getElementById("chat-messages");
    const chatForm = document.getElementById("chat-form");
    const userInput = document.getElementById("user-input");
    const sendBtn = document.getElementById("send-btn");
    const typingIndicator = document.getElementById("typing-indicator");
    const chipButtons = document.querySelectorAll(".chip-btn");

    /**
     * Gets the current local time formatted as HH:MM AM/PM.
     * @returns {string} Formatted timestamp.
     */
    function getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    /**
     * Simple client-side Markdown formatter for bot response text.
     * Converts bold (**text**), italics (*text*), headers, and line breaks into clean HTML.
     * 
     * @param {string} text Raw text with markdown formatting.
     * @returns {string} HTML string.
     */
    function formatMarkdown(text) {
        if (!text) return "";

        let html = text;

        // Escape existing HTML tags to prevent XSS vulnerabilities
        html = html.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

        // Bold: **text** -> <strong>text</strong>
        html = html.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

        // Italics: *text* -> <em>text</em>
        html = html.replace(/\*(.*?)\*/g, "<em>$1</em>");

        // Convert line breaks (\n) into HTML breaks
        html = html.replace(/\n/g, "<br>");

        return html;
    }

    /**
     * Appends a message bubble (user or bot) to the chat history scroll area.
     * 
     * @param {string} sender 'user' or 'bot'
     * @param {string} text Message content
     */
    function appendMessage(sender, text) {
        const isUser = sender === "user";
        const messageRow = document.createElement("div");
        messageRow.classList.add("message-row", isUser ? "user-row" : "bot-row");

        const avatar = document.createElement("div");
        avatar.classList.add("avatar");
        avatar.innerHTML = isUser ? '<i class="fa-solid fa-user"></i>' : '<i class="fa-solid fa-robot"></i>';

        const bubble = document.createElement("div");
        bubble.classList.add("message-bubble");

        const formattedContent = isUser ? escapeHtml(text) : formatMarkdown(text);
        
        bubble.innerHTML = `
            <div>${formattedContent}</div>
            <span class="message-time">${getCurrentTime()}</span>
        `;

        messageRow.appendChild(avatar);
        messageRow.appendChild(bubble);

        chatMessages.appendChild(messageRow);

        // Auto-scroll chat area to latest message
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    /**
     * Helper to safely escape HTML tags for user inputs.
     * @param {string} str Raw user input string.
     * @returns {string} Escaped string.
     */
    function escapeHtml(str) {
        const div = document.createElement("div");
        div.innerText = str;
        return div.innerHTML;
    }

    /**
     * Shows the animated typing indicator.
     */
    function showTyping() {
        typingIndicator.style.display = "flex";
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    /**
     * Hides the typing indicator.
     */
    function hideTyping() {
        typingIndicator.style.display = "none";
    }

    /**
     * Asynchronously sends the user message to the Flask REST API endpoint (/api/chat).
     * 
     * @param {string} message Text string entered by the user.
     */
    async function sendMessage(message) {
        const trimmedMessage = message.trim ? message.trim() : message;

        if (!trimmedMessage) return;

        // Display user message in chat log
        appendMessage("user", message);
        userInput.value = "";

        showTyping();
        sendBtn.disabled = true;

        try {
            const response = await fetch("/api/chat", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ message: trimmedMessage })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            // Brief artificial delay for smooth user experience (200ms)
            setTimeout(() => {
                hideTyping();
                appendMessage("bot", data.response || "No response received.");
                sendBtn.disabled = false;
                userInput.focus();
            }, 200);

        } catch (error) {
            console.error("Error communicating with MovieMatch API:", error);
            hideTyping();
            appendMessage("bot", "⚠️ **Connection Error:** Could not reach the MovieMatch backend server. Please verify Flask is running.");
            sendBtn.disabled = false;
            userInput.focus();
        }
    }

    // Initialize with bot welcome message
    const initialWelcome = 
        "👋 **Hello! Welcome to MovieMatch.**\n\n" +
        "I am your traditional movie recommendation assistant. I can suggest great films based on your preference for:\n" +
        "• **Genre** (Action, Comedy, Horror, Science Fiction, Drama, Thriller, Fantasy, Romance)\n" +
        "• **Mood** (funny, scary, exciting, serious, romantic, suspenseful, adventurous, thought-provoking)\n" +
        "• **Subgenre** (slasher, AI sci-fi, space sci-fi, dark comedy, superhero, crime thriller)\n" +
        "• **Decade** (1970s, 1980s, 1990s, 2000s, 2010s, 2020s)\n\n" +
        "How can I help you find a movie today? (Type **'help'** anytime to view capabilities).";

    appendMessage("bot", initialWelcome);

    // Event Listener: Form Submit (Send Button or Enter Key)
    chatForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const text = userInput.value;
        if (text && text.trim().length > 0) {
            sendMessage(text);
        }
    });

    // Event Listener: Direct Send Button Click Backup
    sendBtn.addEventListener("click", (e) => {
        const text = userInput.value;
        if (text && text.trim().length > 0) {
            e.preventDefault();
            sendMessage(text);
        }
    });

    // Event Listener: Quick Suggestion Chips
    chipButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const promptText = btn.getAttribute("data-prompt");
            if (promptText) {
                sendMessage(promptText);
            }
        });
    });
});
