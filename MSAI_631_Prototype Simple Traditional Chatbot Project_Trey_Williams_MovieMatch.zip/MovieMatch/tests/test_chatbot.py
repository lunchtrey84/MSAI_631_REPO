"""
Automated Test Suite for MovieMatch Chatbot
-------------------------------------------
This module uses Python's standard `unittest` framework (compatible with `pytest`)
to verify all primary functions and decision paths of the MovieMatch chatbot.

Tested Capabilities:
1. Greeting response
2. Help & Capabilities command
3. Comedy keyword matching
4. Horror keyword matching
5. Science fiction keyword matching
6. Decade matching (e.g. 1980s / 80s)
7. Subgenre matching (slasher, AI sci-fi)
8. Malformed input fallback
9. Blank input handling
10. Goodbye closing message
"""

import unittest
from chatbot import MovieMatchBot, normalize_text


class TestMovieMatchBot(unittest.TestCase):
    """
    Test cases covering core functionality of MovieMatchBot.
    """

    @classmethod
    def setUpClass(cls):
        """
        Instantiate the chatbot engine once before running tests.
        """
        cls.bot = MovieMatchBot(data_path="movies.json")

    def test_01_text_normalization(self):
        """
        Verify that text normalization correctly strips punctuation, converts to lower case,
        and resolves decade contractions.
        """
        self.assertEqual(normalize_text("  I WANT SOMETHING FUNNY!!!  "), "i want something funny")
        self.assertEqual(normalize_text("1980's movies!"), "1980s movies")
        self.assertEqual(normalize_text("  "), "")

    def test_02_greeting(self):
        """
        Test greeting intent detection and greeting response text.
        """
        res_hi = self.bot.process_message("hello")
        self.assertEqual(res_hi["intent"], "greeting")
        self.assertIn("MovieMatch", res_hi["response"])

        res_hey = self.bot.process_message("hi there")
        self.assertEqual(res_hey["intent"], "greeting")

    def test_03_help_and_capabilities(self):
        """
        Test that 'help', 'capabilities', and 'what can you do' return the capabilities menu.
        """
        for prompt in ["help", "capabilities", "what can you do"]:
            res = self.bot.process_message(prompt)
            self.assertEqual(res["intent"], "capabilities_help")
            self.assertIn("Capabilities", res["response"])
            self.assertIn("Genres", res["response"])

    def test_04_comedy_keyword(self):
        """
        Test comedy keyword recognition ('funny' -> comedy).
        """
        res = self.bot.process_message("I want something funny")
        self.assertEqual(res["intent"], "recommendation")
        self.assertTrue(len(res["recommendations"]) > 0)
        # All returned recommendations should be Comedy
        for m in res["recommendations"]:
            self.assertEqual(m["genre"], "Comedy")

    def test_05_horror_keyword(self):
        """
        Test horror keyword recognition ('scary' -> horror).
        """
        res = self.bot.process_message("I want something scary")
        self.assertEqual(res["intent"], "recommendation")
        self.assertTrue(len(res["recommendations"]) > 0)
        for m in res["recommendations"]:
            self.assertEqual(m["genre"], "Horror")

    def test_06_science_fiction_keyword(self):
        """
        Test sci-fi keyword recognition ('sci-fi' -> science fiction).
        """
        res = self.bot.process_message("I want a sci-fi movie")
        self.assertEqual(res["intent"], "recommendation")
        self.assertTrue(len(res["recommendations"]) > 0)
        for m in res["recommendations"]:
            self.assertEqual(m["genre"], "Science Fiction")

    def test_07_decade_matching(self):
        """
        Test decade matching ('1980s' or '80s').
        """
        res = self.bot.process_message("I want something from the 1980s")
        self.assertEqual(res["intent"], "recommendation")
        self.assertTrue(len(res["recommendations"]) > 0)
        for m in res["recommendations"]:
            self.assertEqual(m["decade"], "1980s")

    def test_08_subgenre_matching(self):
        """
        Test subgenre matching ('slasher' and 'artificial intelligence science fiction').
        """
        res_slasher = self.bot.process_message("Show me a slasher movie")
        self.assertEqual(res_slasher["intent"], "recommendation")
        self.assertTrue(len(res_slasher["recommendations"]) > 0)
        for m in res_slasher["recommendations"]:
            self.assertEqual(m["subgenre"], "slasher")

        res_ai = self.bot.process_message("artificial intelligence movies")
        self.assertEqual(res_ai["intent"], "recommendation")
        self.assertTrue(len(res_ai["recommendations"]) > 0)
        for m in res_ai["recommendations"]:
            self.assertEqual(m["subgenre"], "artificial intelligence science fiction")

    def test_09_malformed_input(self):
        """
        Test graceful handling of random/malformed input ('asdfghjkl!!!').
        """
        res = self.bot.process_message("asdfghjkl!!!")
        self.assertEqual(res["intent"], "unknown_fallback")
        self.assertIn("did not understand", res["response"].lower())
        self.assertIn("help", res["response"].lower())

    def test_10_blank_input(self):
        """
        Test graceful handling of blank/whitespace input.
        """
        res = self.bot.process_message("   ")
        self.assertEqual(res["intent"], "blank_input")
        self.assertIn("enter a question", res["response"].lower())

    def test_11_goodbye(self):
        """
        Test goodbye intent ('bye').
        """
        res = self.bot.process_message("bye")
        self.assertEqual(res["intent"], "goodbye")
        self.assertIn("MovieMatch", res["response"])


if __name__ == "__main__":
    unittest.main()
