# MovieMatch – Traditional Movie Recommendation Chatbot

A deterministic, rule-based traditional chatbot built in Python and Flask for recommending movies based on user preferences. Designed for a graduate-level computer science assignment.

---

## 📌 Project Overview & Purpose

**MovieMatch** is an interactive web-based movie recommendation assistant. Unlike modern LLM-based systems, MovieMatch operates using **traditional, deterministic techniques** such as string normalization, keyword extraction, intent parsing, synonym mapping, and structured JSON filtering.

This project explicitly avoids runtime dependencies on Large Language Models (LLMs), OpenAI APIs, Gemini APIs, machine learning inference engines, vector databases, or text-generation services. It demonstrates foundational AI concept modeling, rule engineering, input sanitization, and clean architectural separation.

---

## 🛠️ Technology Stack

- **Backend:** Python 3 (Flask Web Framework)
- **Data Storage:** JSON (`movies.json`)
- **Frontend:** HTML5, Vanilla CSS3 (Custom Dark Mode & Glassmorphism design), Vanilla JavaScript (ES6+ Async/Fetch)
- **Testing:** Python `unittest` / `pytest`
- **Architecture:** Decoupled RESTful API (`POST /api/chat`)

---

## 📂 Project Directory Structure

```text
movie-chatbot/
│
├── app.py              # Flask web server, routing, and REST API endpoint
├── chatbot.py          # Core chatbot engine (normalization, intent detection, movie filtering)
├── movies.json         # Predefined structured movie database (30+ movies)
├── requirements.txt    # Python dependency manifest
├── README.md           # Project documentation and development lifecycle
├── .gitignore          # Git exclusion rules
│
├── templates/
│   └── index.html      # Single-page HTML5 chat interface
│
├── static/
│   ├── style.css       # Responsive dark-mode styling system
│   └── script.js       # Asynchronous frontend API controller & DOM updater
│
└── tests/
    ├── __init__.py     # Test package initializer
    └── test_chatbot.py # Automated unit test suite (11 test cases)
```

---

## 🚀 Installation & Setup Instructions

### Prerequisites
- Python 3.9 or higher installed on your system.

### Step 1: Clone or Extract the Project
Navigate to the project root directory in your terminal:
```bash
cd movie-chatbot
```

### Step 2: Create a Virtual Environment

**On Windows (PowerShell / Command Prompt):**
```cmd
python -m venv venv
venv\Scripts\activate
```

**On macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Web Server
```bash
python app.py
```

### Step 5: Access the Web Interface
Open your web browser and navigate to:
```text
http://127.0.0.1:5000
```

---

## 🧪 Running Automated Tests

MovieMatch includes a comprehensive unit test suite covering greetings, help commands, keyword normalization, decade matching, subgenres, malformed input, blank input, and goodbye logic.

Run tests using `pytest`:
```bash
pytest tests/test_chatbot.py -v
```

Or run tests using standard Python `unittest`:
```bash
python -m unittest discover tests
```

---

## 💬 Example Interactions

| User Prompt | Detected Intent | Expected Chatbot Response |
| :--- | :--- | :--- |
| `"hello"` | `greeting` | Welcomes user and outlines bot recommendation capabilities. |
| `"what can you do?"` | `capabilities_help` | Displays the formatted help menu and available genres, moods, subgenres, and decades. |
| `"I want something funny"` | `recommendation` | Recognizes `"funny"` -> Comedy genre and returns movies like *Knives Out*, *Hot Fuzz*, *Superbad*. |
| `"I want something scary"` | `recommendation` | Recognizes `"scary"` -> Horror genre and returns horror movies. |
| `"I want a sci-fi movie"` | `recommendation` | Returns Science Fiction recommendations and offers subgenre options (space, AI, horror). |
| `"I want something from the 1980s"` | `recommendation` | Filters movies released between 1980–1989 (*The Thing*, *The Shining*, *Back to the Future*). |
| `"Show me a slasher movie"` | `recommendation` | Filters for subgenre `slasher` (*A Nightmare on Elm Street*, *Scream*). |
| `"asdfghjkl!!!"` | `unknown_fallback` | Graceful fallback: *"I did not understand that request. Type 'help' to see what I can do."* |
| `""` *(blank input)* | `blank_input` | Requests prompt: *"Please enter a question or movie preference!"* |
| `"bye"` | `goodbye` | Politer closing message: *"Thank you for using MovieMatch! Enjoy your movie..."* |

---

## 📘 Chatbot Development Lifecycle

This section documents the engineering methodology followed during the development of MovieMatch, adhering to traditional software engineering standards:

### 1. Requirements Analysis
- **Goal:** Build a traditional, non-LLM movie recommendation chatbot for academic evaluation.
- **Inputs Identified:** Genre keywords, mood descriptors, subgenres, release decades, system commands (`help`, `bye`), and invalid/blank inputs.
- **Constraints:** Zero dependencies on external generative AI services; completely deterministic execution; clean PEP 8 Python code; responsive web UI.

### 2. Design
- **Deterministic Logic:** Engineered regular expression normalization, lowercasing, punctuation stripping, and tokenized keyword-to-category mapping (`SYNONYMS` dictionary).
- **Data Architecture:** Schema designed in `movies.json` incorporating fields: `id`, `title`, `year`, `decade`, `genre`, `subgenre`, `mood`, `director`, `rating`, `description`.
- **Flask REST Architecture:** Separated HTTP endpoint delivery (`app.py`) from intent processing (`chatbot.py`).
- **UI Design:** Designed a glassmorphic dark-mode web window with quick-select prompt chips and responsive message bubbles.

### 3. Development
- Built `normalize_text()` to handle contractions (`1980's` -> `1980s`) and token cleaning.
- Implemented `MovieMatchBot.process_message()` pipeline prioritizing explicit commands (`help`, `bye`), subgenres, decades, and genre/mood synonyms.
- Created `app.py` Flask routes and frontend AJAX controllers in JavaScript.

### 4. Testing
- Created 11 automated unit test functions covering 100% of defined intent paths.
- Conducted manual browser testing across desktop and mobile layout viewports.

### 5. Deployment and Documentation
- Documented environment initialization and execution commands.
- Created Git repository configuration (`.gitignore`) and ready-to-submit ZIP package structure.

### 6. Maintenance and Future Development
- **Dataset Expansion:** New movies can be added directly to `movies.json` without modifying code.
- **Future AI Integration Readiness:** The `MovieMatchBot` class provides a clean abstract wrapper interface. To extend with AI-as-a-service (e.g. OpenAI/Gemini) in future courses, one can inject an AI provider class implementing `get_response(user_input)` without altering `app.py` or the frontend UI.

---

## ⚙️ Limitations & Future Improvements

### Current Limitations
- Reliance on predefined keywords; non-synonym natural language variations outside rule sets fall back to the help prompt.
- Dataset limited to the curated records stored in `movies.json`.

### Future Enhancements
- Integration with external movie database APIs (e.g. TMDB) for live data updates.
- Hybrid rule-based + LLM fallback adapter pattern.
- User rating and bookmarking system.
