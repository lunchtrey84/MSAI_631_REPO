"""
MovieMatch - Traditional Movie Recommendation Chatbot Engine
-------------------------------------------------------------
This module implements the core deterministic decision logic for MovieMatch.
It relies on rule-based processing, keyword normalization, synonym resolution,
and structured JSON dataset filtering.

Architectural Note for Graduate Course Assignment:
No generative LLM or external AI API is used at runtime. The chatbot engine
uses pure Python techniques (regex, string normalization, dictionary mapping)
to ensure total predictability, rapid performance, and transparent academic explainability.
It is decoupled via the `MovieMatchBot` class so an AI provider could be plugged in
as an adapter in future iterations without refactoring the application layer.
"""

import json
import os
import re
from typing import Dict, List, Any, Optional


def normalize_text(text: str) -> str:
    """
    Normalizes input text for deterministic keyword matching.

    Steps performed:
    1. Trims leading and trailing whitespace.
    2. Converts to lowercase.
    3. Standardizes common terms like 'sci-fi' -> 'science fiction'.
    4. Strips non-alphanumeric characters (except spaces).
    5. Replaces multiple consecutive spaces with a single space.

    Args:
        text (str): Raw string input from the user interface.

    Returns:
        str: Cleaned, normalized string ready for token inspection.
    """
    if not text:
        return ""

    # Convert to lower case and strip outer whitespace
    cleaned = text.strip().lower()

    # Replace common contraction forms before stripping punctuation
    cleaned = re.sub(r"(\d{2,4})'s\b", r"\1s", cleaned)  # e.g., 1980's -> 1980s, 80's -> 80s

    # Standardize sci-fi variations before removing punctuation
    cleaned = re.sub(r"\bsci[-_\s]?fi\b", "science fiction", cleaned)
    cleaned = re.sub(r"\bscifi\b", "science fiction", cleaned)

    # Keep alphanumeric characters and spaces, replace other punctuation with spaces
    cleaned = re.sub(r"[^\w\s]", " ", cleaned)

    # Collapse multiple spaces into a single space
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    return cleaned


class MovieMatchBot:
    """
    Deterministic rule-based chatbot for recommending movies based on user preferences.
    """

    # Keyword to category mappings & synonym dictionaries
    SYNONYMS = {
        # Mood & Genre Synonyms
        "funny": "comedy",
        "hilarious": "comedy",
        "humorous": "comedy",
        "laugh": "comedy",
        "comedies": "comedy",
        "comedy": "comedy",

        "scary": "horror",
        "spooky": "horror",
        "frightening": "horror",
        "horrifying": "horror",
        "horror": "horror",

        "sci-fi": "science fiction",
        "scifi": "science fiction",
        "science fiction": "science fiction",
        "futuristic": "science fiction",
        "space": "space science fiction",

        "romantic": "romance",
        "romance": "romance",
        "love": "romance",
        "romcom": "romance",

        "suspense": "thriller",
        "suspenseful": "thriller",
        "thrilling": "thriller",
        "thriller": "thriller",
        "thrillers": "thriller",

        "exciting": "action",
        "action": "action",
        "action-packed": "action",
        "explosive": "action",

        "serious": "serious",
        "dramatic": "drama",
        "drama": "drama",

        "adventurous": "adventurous",
        "adventure": "fantasy",
        "fantasy": "fantasy",

        "thought-provoking": "thought-provoking",
        "mind-bending": "thought-provoking",

        # Subgenre Specifics
        "slasher": "slasher",
        "slasher movie": "slasher",

        "psychological horror": "psychological horror",
        "psycho horror": "psychological horror",

        "sci-fi horror": "science-fiction horror",
        "science-fiction horror": "science-fiction horror",
        "scifi horror": "science-fiction horror",

        "space science fiction": "space science fiction",

        "artificial intelligence science fiction": "artificial intelligence science fiction",
        "artificial intelligence": "artificial intelligence science fiction",
        "ai": "artificial intelligence science fiction",
        "robot": "artificial intelligence science fiction",

        "dark comedy": "dark comedy",
        "black comedy": "dark comedy",

        "action comedy": "action comedy",
        "superhero": "superhero",
        "comic book": "superhero",

        "crime thriller": "crime thriller",
        "crime": "crime thriller",
    }

    # Decade mappings
    DECADE_MAP = {
        "1970s": "1970s", "70s": "1970s", "seventies": "1970s", "1970": "1970s",
        "1980s": "1980s", "80s": "1980s", "eighties": "1980s", "1980": "1980s",
        "1990s": "1990s", "90s": "1990s", "nineties": "1990s", "1990": "1990s",
        "2000s": "2000s", "00s": "2000s", "naughties": "2000s", "2000": "2000s",
        "2010s": "2010s", "10s": "2010s", "2010": "2010s",
        "2020s": "2020s", "20s": "2020s", "2020": "2020s",
    }

    def __init__(self, data_path: str = "movies.json"):
        """
        Initializes the chatbot and loads the movie dataset from JSON.

        Args:
            data_path (str): Relative or absolute file path to movies.json.
        """
        self.data_path = data_path
        self.movies: List[Dict[str, Any]] = self._load_movies()

    def _load_movies(self) -> List[Dict[str, Any]]:
        """
        Safely reads and parses the JSON movie database.

        Returns:
            List[Dict[str, Any]]: A list of movie dictionaries.
        """
        if not os.path.exists(self.data_path):
            print(f"[Warning] Movie dataset file not found at {self.data_path}. Using empty dataset.")
            return []

        try:
            with open(self.data_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as err:
            print(f"[Error] Failed to read {self.data_path}: {err}")
            return []

    def get_capabilities(self) -> str:
        """
        Generates a clear academic summary of chatbot capabilities.

        Returns:
            str: Formatted text listing supported genres, moods, subgenres, and commands.
        """
        return (
            "🤖 **MovieMatch Capabilities & Help Menu**\n\n"
            "I am a traditional deterministic movie recommendation bot. Here is what I can do for you:\n\n"
            "🎬 **Supported Genres:** Action, Comedy, Horror, Science Fiction, Drama, Thriller, Fantasy, Romance.\n"
            "😊 **Supported Moods:** funny, scary, exciting, serious, romantic, suspenseful, adventurous, thought-provoking.\n"
            "🎯 **Supported Subgenres:** science-fiction horror, psychological horror, slasher, space science fiction, artificial intelligence science fiction, dark comedy, action comedy, superhero, crime thriller.\n"
            "📅 **Decades:** 1970s, 1980s, 1990s, 2000s, 2010s, 2020s.\n\n"
            "💡 **Example Prompts You Can Try:**\n"
            "• *\"I want something funny\"*\n"
            "• *\"Recommend a scary horror movie\"*\n"
            "• *\"Show me artificial intelligence science fiction movies\"*\n"
            "• *\"Give me a slasher movie from the 1980s\"*\n"
            "• *\"I want something from the 1990s\"*\n"
            "• *\"type 'bye' to exit\"*"
        )

    def get_greeting(self) -> str:
        """
        Returns a friendly welcome message describing bot capabilities.
        """
        return (
            "👋 **Hello! Welcome to MovieMatch.**\n\n"
            "I am your movie recommendation assistant. I can suggest great films based on your preference for:\n"
            "• **Genre** (e.g., Action, Comedy, Horror, Science Fiction, Drama, Thriller, Fantasy, Romance)\n"
            "• **Mood** (e.g., funny, scary, exciting, serious, romantic, suspenseful, adventurous, thought-provoking)\n"
            "• **Subgenre** (e.g., slasher, AI sci-fi, space sci-fi, dark comedy, superhero, crime thriller)\n"
            "• **Decade** (e.g., 1970s, 1980s, 1990s, 2000s, 2010s, 2020s)\n\n"
            "How can I help you find a movie today? (Type **'help'** anytime to view capabilities)."
        )

    def get_goodbye(self) -> str:
        """
        Returns a polite farewell message.
        """
        return "👋 Thank you for using **MovieMatch**! Enjoy your movie and have a wonderful day!"

    def find_movies(
        self,
        genre: Optional[str] = None,
        subgenre: Optional[str] = None,
        mood: Optional[str] = None,
        decade: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Filters the dataset deterministically based on provided matching criteria.

        Args:
            genre (str, optional): Target genre (case-insensitive).
            subgenre (str, optional): Target subgenre (case-insensitive).
            mood (str, optional): Target mood (case-insensitive).
            decade (str, optional): Target decade (e.g., "1980s").

        Returns:
            List[Dict[str, Any]]: Filtered list of matching movie records.
        """
        results = []

        for m in self.movies:
            match = True

            if genre and m.get("genre", "").strip().lower() != genre.strip().lower():
                match = False
            if subgenre and m.get("subgenre", "").strip().lower() != subgenre.strip().lower():
                match = False
            if mood and m.get("mood", "").strip().lower() != mood.strip().lower():
                match = False
            if decade and m.get("decade", "").strip().lower() != decade.strip().lower():
                match = False

            if match:
                results.append(m)

        return results

    def format_movie_list(self, movies: List[Dict[str, Any]], header: str) -> str:
        """
        Formats a list of movie objects into a clean, human-readable markdown response.

        Args:
            movies (List[Dict[str, Any]]): List of matching movie objects.
            header (str): Contextual introductory string for the user.

        Returns:
            str: Formatted markdown string.
        """
        if not movies:
            return f"{header}\n\nNo movies in our current database match all your specified criteria. Try broadening your request (e.g., searching by genre or mood)!"

        response = f"{header}\n\n"
        for idx, m in enumerate(movies, 1):
            response += (
                f"🍿 **{idx}. {m['title']}** ({m['year']})\n"
                f"   • **Genre:** {m['genre']} ({m['subgenre']})\n"
                f"   • **Mood:** {m['mood'].capitalize()} | **Director:** {m.get('director', 'N/A')}\n"
                f"   • **Summary:** {m['description']}\n\n"
            )
        return response.strip()

    def process_message(self, user_input: str) -> Dict[str, Any]:
        """
        Master decision function that parses user input, executes intent detection,
        queries the movie dataset, and returns a response payload.

        Args:
            user_input (str): Raw string submitted by the user.

        Returns:
            Dict[str, Any]: Payload containing 'response', 'intent', and 'recommendations'.
        """
        # Step 1: Check for blank / whitespace-only input
        if not user_input or not user_input.strip():
            return {
                "intent": "blank_input",
                "response": "Please enter a question or movie preference! (e.g., 'I want something funny', 'Recommend a horror movie', or type 'help').",
                "recommendations": []
            }

        # Step 2: Normalize input text
        clean = normalize_text(user_input)

        # Step 3: Check for exact system commands / intents
        if clean in ["help", "capabilities", "what can you do", "info", "options", "menu", "commands"]:
            return {
                "intent": "capabilities_help",
                "response": self.get_capabilities(),
                "recommendations": []
            }

        if any(w in clean.split() for w in ["hello", "hi", "hey", "greetings", "start", "welcome"]):
            return {
                "intent": "greeting",
                "response": self.get_greeting(),
                "recommendations": []
            }

        if clean in ["bye", "goodbye", "exit", "quit", "see ya", "farewell", "stop"]:
            return {
                "intent": "goodbye",
                "response": self.get_goodbye(),
                "recommendations": []
            }

        # Step 4: Extract parameters (Subgenre, Decade, Mood, Genre)
        detected_subgenre = None
        detected_decade = None
        detected_mood = None
        detected_genre = None

        # Detect subgenres first (since subgenres like 'science-fiction horror' are specific)
        for key in ["science-fiction horror", "psychological horror", "slasher",
                    "space science fiction", "artificial intelligence science fiction",
                    "dark comedy", "action comedy", "superhero", "crime thriller"]:
            if key in clean:
                detected_subgenre = key
                break

        # Check subgenre aliases in normalized text
        if not detected_subgenre:
            if "slasher" in clean:
                detected_subgenre = "slasher"
            elif "psychological horror" in clean or "psycho horror" in clean:
                detected_subgenre = "psychological horror"
            elif "sci-fi horror" in clean or "scifi horror" in clean:
                detected_subgenre = "science-fiction horror"
            elif "space sci-fi" in clean or "space science fiction" in clean:
                detected_subgenre = "space science fiction"
            elif "ai" in clean.split() or "artificial intelligence" in clean or "robot" in clean.split():
                detected_subgenre = "artificial intelligence science fiction"
            elif "dark comedy" in clean or "black comedy" in clean:
                detected_subgenre = "dark comedy"
            elif "action comedy" in clean:
                detected_subgenre = "action comedy"
            elif "superhero" in clean or "comic book" in clean:
                detected_subgenre = "superhero"
            elif "crime thriller" in clean or "crime" in clean.split():
                detected_subgenre = "crime thriller"

        # Detect decades
        for word, dec in self.DECADE_MAP.items():
            if re.search(r"\b" + re.escape(word) + r"\b", clean):
                detected_decade = dec
                break

        # Detect genre / mood keywords (handles multi-word terms like "science fiction")
        for syn_key, mapped_val in self.SYNONYMS.items():
            if re.search(r"\b" + re.escape(syn_key) + r"\b", clean):
                if mapped_val in ["action", "comedy", "horror", "science fiction", "drama", "thriller", "fantasy", "romance"]:
                    if not detected_genre:
                        detected_genre = mapped_val
                elif mapped_val in ["funny", "scary", "exciting", "serious", "romantic", "suspenseful", "adventurous", "thought-provoking"]:
                    if not detected_mood:
                        detected_mood = mapped_val

        # Handle specific genre/mood logic based on requirements:
        # e.g., "funny" maps to comedy, "scary" maps to horror
        if "funny" in clean or "humorous" in clean or "hilarious" in clean:
            detected_genre = "comedy"
            detected_mood = "funny"
        if "scary" in clean or "spooky" in clean or "frightening" in clean:
            detected_genre = "horror"
            detected_mood = "scary"
        if "exciting" in clean:
            detected_genre = "action"
            detected_mood = "exciting"
        if "romantic" in clean:
            detected_genre = "romance"
            detected_mood = "romantic"
        if "suspense" in clean or "suspenseful" in clean:
            detected_genre = "thriller"
            detected_mood = "suspenseful"

        # If subgenre is detected, automatically map parent genre if not set
        if detected_subgenre:
            if detected_subgenre in ["science-fiction horror", "psychological horror", "slasher"]:
                detected_genre = "horror"
            elif detected_subgenre in ["space science fiction", "artificial intelligence science fiction"]:
                detected_genre = "science fiction"
            elif detected_subgenre in ["dark comedy", "action comedy"]:
                detected_genre = "comedy"
            elif detected_subgenre == "superhero":
                detected_genre = "action"
            elif detected_subgenre == "crime thriller":
                detected_genre = "thriller"

        # Step 5: Execute deterministic database search based on criteria
        if detected_subgenre or detected_decade or detected_genre or detected_mood:
            matches = self.find_movies(
                genre=detected_genre,
                subgenre=detected_subgenre,
                mood=detected_mood,
                decade=detected_decade
            )

            # Build contextual description header
            criteria_parts = []
            if detected_decade:
                criteria_parts.append(f"from the {detected_decade}")
            if detected_subgenre:
                criteria_parts.append(f"in the {detected_subgenre} subgenre")
            elif detected_genre:
                criteria_parts.append(f"in the {detected_genre.capitalize()} genre")
            if detected_mood and not detected_subgenre:
                criteria_parts.append(f"with a {detected_mood} mood")

            context_str = " ".join(criteria_parts)
            header = f"Here are the top movie recommendations {context_str}:" if context_str else "Here are movie recommendations for you:"

            # Special follow-up options for broad Science Fiction query as requested in requirements
            if detected_genre == "science fiction" and not detected_subgenre:
                header += "\n\n*(Tip: You can also narrow down sci-fi by specifying **space**, **artificial intelligence**, or **science-fiction horror**!)*"

            formatted_res = self.format_movie_list(matches, header)

            return {
                "intent": "recommendation",
                "response": formatted_res,
                "recommendations": matches
            }

        # Step 6: Fallback for malformed / unrecognized input
        return {
            "intent": "unknown_fallback",
            "response": (
                "I did not understand that request. MovieMatch works using keyword and preference rules.\n\n"
                "Type **'help'** to see what I can do, or try asking for a genre (e.g. *'comedy'*), mood (e.g. *'scary'*), or decade (e.g. *'1980s'*)."
            ),
            "recommendations": []
        }
