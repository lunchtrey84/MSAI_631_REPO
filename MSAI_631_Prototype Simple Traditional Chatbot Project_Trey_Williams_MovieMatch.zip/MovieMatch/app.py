"""
MovieMatch - Flask Web Application Server
------------------------------------------
This server exposes the REST API endpoint for the MovieMatch chatbot
and serves the single-page HTML web interface.

Architectural Design:
- Decouples HTTP request/response routing from chatbot recommendation business logic.
- Implements CORS & JSON API standards for clear academic demonstration.
"""

from flask import Flask, render_template, request, jsonify
from chatbot import MovieMatchBot

# Initialize Flask web application
app = Flask(__name__)

# Instantiate the deterministic chatbot engine
bot = MovieMatchBot(data_path="movies.json")


@app.route("/")
def index():
    """
    Renders the main single-page chat interface.

    Returns:
        HTML document rendered from templates/index.html.
    """
    return render_template("index.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    """
    API endpoint for handling incoming chatbot messages from the frontend.

    Expected Request JSON Body:
        {
            "message": "User text input string"
        }

    Returns:
        JSON response object containing response text, detected intent, and recommendations:
        {
            "response": "Formatted bot message",
            "intent": "Detected intent identifier",
            "recommendations": [...]
        }
    """
    try:
        data = request.get_json(silent=True)

        if not data:
            return jsonify({
                "error": "Invalid request. JSON body expected.",
                "response": "An error occurred processing your request. Please send valid JSON.",
                "intent": "error",
                "recommendations": []
            }), 400

        user_message = data.get("message", "")

        # Process message using the deterministic chatbot engine
        result = bot.process_message(user_message)

        return jsonify(result), 200

    except Exception as err:
        print(f"[Error] Internal server error processing /api/chat: {err}")
        return jsonify({
            "error": str(err),
            "response": "An unexpected server error occurred. Please try again.",
            "intent": "server_error",
            "recommendations": []
        }), 500


if __name__ == "__main__":
    print("Starting MovieMatch Flask Web Server on http://127.0.0.1:5000 ...")
    app.run(host="127.0.0.1", port=5000, debug=True)
